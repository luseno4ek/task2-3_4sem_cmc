template <typename Type>
struct ListNode {
    Type data;
    ListNode* next;
    ListNode* previous;
    ListNode(const Type& _data, ListNode<Type>* _next = nullptr,
                                        ListNode<Type>* _previous = nullptr);
    ~ListNode();
};

template <typename Type>
class List {
private:
    ListNode<Type>* ListHead;
public:
    List();
    List(const List& _List);
    ~List();
    void PushFront(const Type& _data);
    void PushBack(const Type& _data);
    Type Front();
    Type Back();
    void PopFront();
    void PopBack();
    void Insert(int p, const Type& _data);
    void Erase(int p);
    bool Empty();
    int Size();
    void Print();
};
