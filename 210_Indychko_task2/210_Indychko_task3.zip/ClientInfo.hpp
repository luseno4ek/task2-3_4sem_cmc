//
//  ClientInfo.hpp
//  210_Indychko_task2
//
//  Created by Олеся Индычко on 12.03.2021.
//

#ifndef ClientInfo_hpp
#define ClientInfo_hpp

#include <stdio.h>

#endif /* ClientInfo_hpp */
